package com.example.examenSpringAlexFuela;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamenSpringAlexFuelaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamenSpringAlexFuelaApplication.class, args);
	}

}
