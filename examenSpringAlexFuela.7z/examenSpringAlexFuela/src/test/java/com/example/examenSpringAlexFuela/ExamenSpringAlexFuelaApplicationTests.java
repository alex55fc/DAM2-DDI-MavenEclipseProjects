package com.example.examenSpringAlexFuela;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamenSpringAlexFuelaApplicationTests {

	@Test
	void contextLoads() {
	}

}
